Folder: task_3_1
Description: Task 3 prompt configured with a 1-second simulation horizon for future prediction analysis.

Folder: task_3_2_5
Description: Task 3 prompt configured with a 2.5-second simulation horizon for future prediction analysis.

Folder: task_3_5
Description: Task 3 prompt configured with a 5-second simulation horizon for future prediction analysis.